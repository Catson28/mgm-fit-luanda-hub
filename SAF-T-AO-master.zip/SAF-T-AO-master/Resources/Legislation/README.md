# Legislation

- 🆕 [Decreto Executivo 317/20 de 14 de Dezembro](decreto-317-20.pdf)
- [Decreto Presidencial 312/18 de 21 de Dezembro](decreto-312-18.pdf)

You can find more legal related information in the AGT (Tax Authority) [website](https://portaldocontribuinte.minfin.gov.ao/legislacao).
